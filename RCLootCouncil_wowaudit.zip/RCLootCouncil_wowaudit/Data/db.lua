wowauditTimestamp = nil
difficulties = {}
wishlistData = {}
